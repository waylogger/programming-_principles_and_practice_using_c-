#include <D:\\Programms\\18\\12\\Game.cpp>


int main ()
{

Game* g = new Game{};
	
	
}

